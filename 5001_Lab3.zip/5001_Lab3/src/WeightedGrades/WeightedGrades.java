package WeightedGrades;
//10 20 30 40 50 100 200 300
//        8.5 19 25 36 45 80 165 153.1
//        10 10 10 10 10 10 15 25
public class WeightedGrades {
    private double total_points;
    private double earned_points;
    private double assignment_percentage;
    private double total_weighted_grades;

    public WeightedGrades (double total_points, double earned_points, double assignment_percentage) {
        this.total_points = total_points;
        this.earned_points = earned_points;
        this.assignment_percentage = assignment_percentage;
    }
    //calculate total weighted grades
    public double calculate() {

        this.total_weighted_grades = this.earned_points / this.total_points * this.assignment_percentage * 100;
        return total_weighted_grades;
    }
    // accessor method
    public double getTotal_points() {
        return total_points;
    }

    public double getEarned_points() {
        return earned_points;
    }

    public double getAssignment_percentage() {
        return assignment_percentage;
    }

    public double getTotal_weighted_grades() {
        return total_weighted_grades;
    }

    //mutator method
    public void setTotal_points(double total_points) {
        this.total_points = total_points;
    }

    public void setEarned_points(double earned_points) {
        this.earned_points = earned_points;
    }

    public void setAssignment_percentage(double assignment_percentage) {
        this.assignment_percentage = assignment_percentage;
    }

    public void setTotal_weighted_grades(double total_weighted_grades) {
        this.total_weighted_grades = total_weighted_grades;
    }
}
